const BUSINESS = { whatsapp: "", address: "", instagram: "" };

const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav-links');
menuButton.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(isOpen));
  menuButton.setAttribute('aria-label', isOpen ? 'Tutup menu' : 'Buka menu');
});
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuButton.setAttribute('aria-expanded', 'false');
  menuButton.setAttribute('aria-label', 'Buka menu');
}));

document.getElementById('year').textContent = new Date().getFullYear();
function showContact() {
  document.getElementById('address-value').textContent = BUSINESS.address || 'Alamat belum dicantumkan';
  document.getElementById('phone-value').textContent = BUSINESS.whatsapp ? '+' + BUSINESS.whatsapp.replace(/\D/g,'') : 'Nomor belum dicantumkan';
  const el = document.getElementById('instagram-value');
  if (BUSINESS.instagram.trim()) {
    const name = BUSINESS.instagram.trim().replace(/^@/,'');
    const link = document.createElement('a');
    link.href = 'https://www.instagram.com/' + encodeURIComponent(name) + '/';
    link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = '@' + name;
    el.replaceChildren(link);
  } else { el.textContent = 'Akun belum dicantumkan'; }
}
function setText(id, value) {
  const el = document.getElementById(id);
  if (el && typeof value === 'string') el.textContent = value;
}
function setImage(id,value) {
  const el=document.getElementById(id);
  if (el && typeof value==='string' && /^(https?:\/\/|\/media\/)/.test(value)) el.src=value;
}
async function loadSite() {
  try {
    const response=await fetch('/content/site.json',{cache:'no-cache'});
    if (!response.ok) throw new Error('Konten belum tersedia');
    const site=await response.json();
    setText('hero-title',site.hero_title);
    setText('hero-description',site.hero_description);
    if (typeof site.hero_image==='string' && /^(https?:\/\/|\/media\/)/.test(site.hero_image))
      document.getElementById('hero-image').style.backgroundImage='url('+JSON.stringify(site.hero_image)+')';
    setText('about-title',site.about_title);
    setText('about-paragraph-1',site.about_paragraph_1);
    setText('about-paragraph-2',site.about_paragraph_2);
    setImage('about-image',site.about_image);
    for (let i=1;i<=3;i++) {
      setText('feature-'+i+'-title',site['feature_'+i+'_title']);
      setText('feature-'+i+'-text',site['feature_'+i+'_text']);
      setImage('gallery-'+i+'-image',site['gallery_'+i+'_image']);
      setText('gallery-'+i+'-caption',site['gallery_'+i+'_caption']);
    }
    setText('gallery-note',site.gallery_note);
    setText('contact-text',site.contact_text);
    BUSINESS.whatsapp=site.whatsapp||'';
    BUSINESS.address=site.address||'';
    BUSINESS.instagram=site.instagram||'';
  } catch(err) { console.warn('Konten CMS belum dimuat:',err); }
  showContact();
}
loadSite();

document.getElementById('contact-form').addEventListener('submit', event => {
  event.preventDefault();
  const status = document.getElementById('form-status');
  const number = BUSINESS.whatsapp.replace(/\D/g,'');
  if (!/^\d{9,15}$/.test(number)) {
    status.textContent = 'Nomor WhatsApp resmi belum diatur. Pemilik perlu mengisi nomor WhatsApp pada panel Pages CMS agar formulir ini berfungsi.';
    status.style.color = '#9b4b31';
    return;
  }
  const form = event.currentTarget;
  const message = `Halo Omah Kebon Kaliaji!\n\nNama: ${form.elements.nama.value.trim()}\nKeperluan: ${form.elements.topik.value}\nPesan: ${form.elements.pesan.value.trim()}`;
  const url = 'https://wa.me/' + number + '?text=' + encodeURIComponent(message);
  status.textContent = 'Membuka WhatsApp dengan pesan Anda…';
  status.style.color = '#36634e';
  window.open(url, '_blank', 'noopener,noreferrer');
});
