LANDING PAGE OMAH KEBON KALIAJI — PANDUAN

Isi folder:
- index.html: isi teks dan struktur halaman
- styles.css: desain dan tampilan responsif
- script.js: menu mobile, informasi kontak, dan tombol WhatsApp

1. LIHAT WEBSITE SECARA OFFLINE
   Klik dua kali index.html, lalu buka dengan browser. Foto dan font dari internet perlu koneksi.

2. GANTI INFORMASI KONTAK (PENTING)
   Buka script.js menggunakan Notepad atau VS Code.
   Di objek BUSINESS, isi:
   whatsapp: "628xxxxxxxxxx"  (nomor WhatsApp resmi, tanpa + atau spasi)
   address: "alamat lengkap"
   instagram: "@akunresmi"
   Simpan. Sebelum diisi, tombol formulir sengaja tidak mengirim pesan ke nomor apa pun.

3. GANTI TEKS DAN FOTO
   Buka index.html, ganti narasi sesuai jenis usaha, jenis layanan/produk, harga, jam operasional, alamat, dll. Teks sekarang adalah contoh kreatif, bukan klaim faktual tentang fasilitas usaha.
   Foto saat ini berasal dari Unsplash sebagai ilustrasi. Agar akurat, ganti URL gambar dalam index.html dan url gambar hero pada styles.css dengan foto asli Anda. Pastikan memiliki izin penggunaan foto.

4. PUBLIKASIKAN GRATIS
   a. Buka https://app.netlify.com/drop
   b. Masuk/buat akun gratis agar mudah mengelola situs.
   c. Ekstrak ZIP hasil unduhan.
   d. Seret FOLDER omah-kebon-kaliaji (yang berisi index.html) ke Netlify Drop.
   e. Netlify memberikan alamat situs netlify.app. Untuk mengubah, gunakan fitur penamaan proyek bila tersedia.
   f. Untuk memperbarui website, edit file lokal lalu unggah ulang folder pada proyek Netlify Anda.
   Hosting gratis tunduk pada batas paket Netlify. Domain khusus dibeli terpisah bila dibutuhkan.

5. CATATAN TEKNIS
   Website statis: tidak membutuhkan server, database, ataupun biaya lisensi.
   Formulir menggunakan WhatsApp melalui wa.me, bukan menyimpan data pengunjung.
   Foto/font eksternal memerlukan internet. Untuk kinerja maksimal, gunakan foto asli yang dikompresi.
